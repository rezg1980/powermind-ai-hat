
PowerMind AI – Control Layer

This module processes smart control rules and triggers GPIO relay outputs based on real-time sensor data (voltage, current, power) from the monitoring layer.

FILES INCLUDED:
---------------
1. smart_control.py
   - Python script to load control rules and drive relays based on sensor input

2. control_rules_template.json
   - JSON template defining when and how relays should respond to power behavior

3. relay_control.py
   - Basic relay test script for manual ON/OFF toggle via GPIO

REQUIREMENTS:
-------------
- Raspberry Pi with GPIO support
- Relay modules (active LOW)
- Sensors (ACS712, voltage divider or detection module)
- Sensor data log file: power_log.csv

TO USE:
-------
1. Configure your relay pins in smart_control.py under `relay_pin_map`
2. Log power data to power_log.csv every second
3. Run `smart_control.py` to automatically apply rule-based actions

NEXT STEP:
----------
Integrate AI layer to provide predictive recommendations to override or adjust control logic dynamically.
