
import time
import board
import busio
import adafruit_ssd1306
from PIL import Image, ImageDraw, ImageFont

# OLED display setup (I2C)
i2c = busio.I2C(board.SCL, board.SDA)
display = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c)

# Clear the display
display.fill(0)
display.show()

# Load default font
font = ImageFont.load_default()

# Create blank image for drawing
width = display.width
height = display.height
image = Image.new("1", (width, height))
draw = ImageDraw.Draw(image)

def show_power_status(voltage, current):
    power = voltage * current
    draw.rectangle((0, 0, width, height), outline=0, fill=0)
    draw.text((0, 0), f"Voltage: {voltage:.2f} V", font=font, fill=255)
    draw.text((0, 16), f"Current: {current:.2f} A", font=font, fill=255)
    draw.text((0, 32), f"Power: {power:.2f} W", font=font, fill=255)
    display.image(image)
    display.show()

# Example usage (replace with real data in loop)
try:
    while True:
        voltage = 12.5  # replace with reading
        current = 1.8   # replace with reading
        show_power_status(voltage, current)
        time.sleep(1)

except KeyboardInterrupt:
    display.fill(0)
    display.show()
