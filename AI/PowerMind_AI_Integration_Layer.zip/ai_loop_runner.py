
import time
import os

while True:
    print("Running AI prediction...")
    os.system("python3 ai_predictor.py")
    time.sleep(60)
