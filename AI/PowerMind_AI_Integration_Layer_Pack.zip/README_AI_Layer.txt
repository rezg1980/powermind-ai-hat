
PowerMind AI – AI Integration Layer

This layer introduces basic AI logic to monitor power data and generate real-time operational recommendations.

FILES INCLUDED:
---------------
1. ai_predictor.py
   - Python script to analyze power_log.csv and output control decisions (ok, standby, shutdown)

2. recommendations.json
   - Output from ai_predictor.py used by the control layer to enhance decisions

FUNCTIONS:
----------
- Monitors last 60 seconds of power data
- Computes average and peak power
- Issues "shutdown" if peak exceeds 600W
- Issues "standby" if average < 50W
- Issues "ok" if within safe range

FUTURE EXPANSIONS:
------------------
- Train smarter models with patterns (e.g., seasonal usage)
- Integrate with cloud ML engines
- Learn from user behavior and override history

TO USE:
-------
1. Schedule ai_predictor.py to run every 60 seconds
2. Ensure power_log.csv is up to date
3. Let control layer read recommendations.json for dynamic logic

Author: Rezkelah Ibrahim
