
import pandas as pd
import json
from datetime import datetime

# CONFIG
POWER_LOG_FILE = "power_log.csv"
RECOMMENDATION_FILE = "recommendations.json"

# Load latest power data
def load_power_data():
    try:
        df = pd.read_csv(POWER_LOG_FILE)
        df = df.tail(60)  # Last 60 seconds (or rows)
        return df
    except Exception as e:
        print("Error reading power log:", e)
        return None

# Analyze and return basic recommendation
def analyze_data(df):
    avg_power = df['power'].mean()
    max_power = df['power'].max()

    if max_power > 600:
        decision = "shutdown"
        reason = "Power peak detected"
    elif avg_power < 50:
        decision = "standby"
        reason = "Very low average usage"
    else:
        decision = "ok"
        reason = "Normal operation"

    return {
        "timestamp": datetime.now().isoformat(),
        "decision": decision,
        "reason": reason,
        "avg_power": avg_power,
        "max_power": max_power
    }

# Write result to JSON
def write_recommendation(data):
    with open(RECOMMENDATION_FILE, "w") as f:
        json.dump(data, f, indent=4)

# Run it
if __name__ == "__main__":
    df = load_power_data()
    if df is not None:
        result = analyze_data(df)
        write_recommendation(result)
        print("AI decision written:", result["decision"])
